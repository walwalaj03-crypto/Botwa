HENDARBOT — VERCEL + BUATQRIS (TANPA GOOGLE LOGIN)

Fitur: daftar/login email + password, dashboard, trial 2 hari sekali per akun, 5 paket berbayar, deposit min Rp5.000, QRIS BuatQRIS, cek status transaksi, owner panel.

PENTING
- Google Login sudah dihapus. Tidak perlu Google Client ID/OAuth.
- Secret BuatQRIS disimpan di Environment Variables server Vercel, bukan file frontend.
- Integrasi mengikuti contoh API yang diberikan: api_create_qris dan api_check_status via POST x-www-form-urlencoded.
- BuatQRIS yang diberikan tidak menyertakan webhook/callback. Status diperiksa saat user menekan tombol Cek status. Jangan menandai pembayaran sukses hanya dari browser.
- HTTP 429 ditangani dengan retry_after yang dikembalikan API. User perlu menunggu sebelum cek ulang.
- Cek respons dan status persis dari akun BuatQRIS pada Sandbox/test nominal kecil dahulu. Pastikan status success hanya dikirim setelah pembayaran benar-benar diterima.
- Pairing WhatsApp masih berupa antrean, belum menghasilkan pairing code sampai source bot utama diintegrasikan.
- Tombol Tutup hanya menutup tampilan, bukan membatalkan transaksi.

DEPLOY
1. Extract ZIP, upload seluruh isi ke root GitHub repository (jangan upload ZIP sebagai satu file).
2. Buat database Neon dan jalankan schema.sql di SQL Editor. Jika database lama sudah ada, ALTER TABLE di schema menambahkan kolom provider_transaction_id.
3. Import repository di https://vercel.com/new. Framework Other, Build Command kosong, Output Directory public, Install Command npm install.
4. Vercel > Project > Settings > Environment Variables, tambahkan:
   DATABASE_URL = connection string Neon
   JWT_SECRET = string acak panjang minimal 32 karakter
   OWNER_EMAIL = email owner
   OWNER_PASSWORD_HASH = hash bcrypt password owner
   BUATQRIS_BASE_URL = https://api.buatqris.site
   BUATQRIS_ACCOUNT_ID = Account ID dari dashboard BuatQRIS
   BUATQRIS_SECRET_TOKEN = Secret Token dari dashboard BuatQRIS
   BUATQRIS_METHOD = qris_two (atau qris_five sesuai akun)
   BUATQRIS_FEE_BY = user atau buyer
   APP_URL = https://hendar.web.id
5. Redeploy setelah mengisi ENV. Jangan menaruh token dalam app.js, HTML, atau GitHub.

Buat hash password owner dengan Node.js:
node -e "console.log(require('bcryptjs').hashSync('PASSWORD_BARU_YANG_KUAT',12))"
Gunakan password baru yang belum pernah dikirim di chat.

DOMAIN
Vercel Project > Settings > Domains > Add hendar.web.id. Ikuti DNS record yang Vercel tampilkan persis; jangan menebak record.

CEK STATUS QRIS
User menekan Cek status. API server mengirim action=api_check_status ke BuatQRIS. Jika API menjawab 429, tampil pesan rate limit. Tunggu retry_after sebelum mencoba lagi.

CATATAN MIGRASI
ZIP ini menggunakan schema yang kompatibel dengan tabel sebelumnya dan menambahkan provider_transaction_id. Jalankan schema.sql sebelum deploy. Pembayaran iPaymu lama tidak otomatis berubah menjadi BuatQRIS.
